library(shiny)
library(dplyr)
library(ggplot2)
library(readxl)
library(cowplot)
library(reshape2)
library(shinythemes)
library(shinyjs)
library(plotly)
library(tidyr)
library(networkD3)
library(GGally)
library(gridExtra)
library(shinydashboard)
library(shinydashboardPlus)
library(glue)


survey <- read_excel("country_allyears.xlsx", sheet = 'Data')
country_options <- unique(survey$Subregion)

question_choices <- c("On a typical day, do you take care of any of the following domestic tasks at least half of the time? Select all that apply",
                      'During the last 30 days, was there a time when you were worried about not having enough food to eat because of lack of money or other resources?',
                      'What level of access to household money do you personally have? Select one',
                      'Do you currently own any of the following? Select all that apply',
                      'How much do you agree or disagree with the following statement? “Men and women should have equal opportunities (e.g. in education, jobs, household decision-making).',
                      'During the last 12 months, which of the following -most closely- reflects your current financial situation?',
                      'In the last 12 months, which of the following were your household’s sources of livelihood?',
                      'How often do you normally get help from others to take care of these family members?',
                      'Who normally helps you in taking care of these family members?',
                      'How has the amount of time you spend caring for your family members changed during the coronavirus  (COVID-19) pandemic compared to before?'
                      
)

data_q1_first <- function(country, selected_gender) {survey %>%
    filter(Subregion == country) %>%
    filter(Gender %in% selected_gender) %>%
    select(sog_w2_dom_tsks_anml, sog_w2_dom_tsks_bus, 
           sog_w2_dom_tsks_clean, sog_w2_dom_tsks_meal,
           sog_w2_dom_tsks_farm, sog_w2_dom_tsks_hshld, 
           sog_w2_dom_tsks_none, sog_w2_dom_tsks_shop, 
           sog_w2_dom_tsks_wtrfl, Subregion) %>%
    rename(
      'anml' = sog_w2_dom_tsks_anml,
      'busns' = sog_w2_dom_tsks_bus,
      'clean' = sog_w2_dom_tsks_clean,
      'meal' = sog_w2_dom_tsks_meal,
      'farm' = sog_w2_dom_tsks_farm,
      'hshld' = sog_w2_dom_tsks_hshld,
      'none' = sog_w2_dom_tsks_none,
      'shop' = sog_w2_dom_tsks_shop,
      'accmd' = sog_w2_dom_tsks_wtrfl) %>%
    melt(id.vars = "Subregion") %>%
    na.omit() %>%
    group_by(variable) %>%
    mutate(value = ifelse(length(selected_gender) == 1, (sum(as.numeric(value)) * 100 / 200), (sum(as.numeric(value)) * 100 / 400))) %>%
    distinct() %>%
    ungroup() %>%
    na.omit()}


data_q1_second <- function(selected_countries, selected_gender){survey %>%
    filter(Subregion %in% selected_countries) %>%
    filter(Gender %in% selected_gender) %>%
    select(sog_w2_dom_tsks_anml, sog_w2_dom_tsks_bus, 
           sog_w2_dom_tsks_clean, sog_w2_dom_tsks_meal,
           sog_w2_dom_tsks_farm, sog_w2_dom_tsks_hshld, 
           sog_w2_dom_tsks_none, sog_w2_dom_tsks_shop, 
           sog_w2_dom_tsks_wtrfl, Subregion) %>%
    rename(
      'anml' = sog_w2_dom_tsks_anml,
      'busns' = sog_w2_dom_tsks_bus,
      'clean' = sog_w2_dom_tsks_clean,
      'meal' = sog_w2_dom_tsks_meal,
      'farm' = sog_w2_dom_tsks_farm,
      'hshld' = sog_w2_dom_tsks_hshld,
      'none' = sog_w2_dom_tsks_none,
      'shop' = sog_w2_dom_tsks_shop,
      'accmd' = sog_w2_dom_tsks_wtrfl) %>%
    melt(id.vars = "Subregion") %>%
    na.omit() %>%
    distinct() %>%
    group_by(Subregion, variable) %>%
    summarise(value = ifelse(length(selected_gender) == 1, (sum(as.numeric(value)) * 100 / 200), 
                             (sum(as.numeric(value)) * 100 / 400)), .groups = 'drop') %>%
    na.omit()}


data_q2_first <-  function(country, selected_gender) {survey %>%
    filter(Subregion == country) %>%
    filter(Gender %in% selected_gender) %>%
    select(sog_w2_wrrd_food_yes,sog_w2_wrrd_food_no,Subregion) %>%
    rename('yes' = sog_w2_wrrd_food_yes,
           'no' = sog_w2_wrrd_food_no) %>%
    melt(id.vars = "Subregion") %>%
    na.omit() %>%
    group_by(variable) %>%
    mutate(value = ifelse(length(selected_gender) == 1, (sum(as.numeric(value)) * 100 / 200), (sum(as.numeric(value)) * 100 / 400))) %>%
    distinct() %>%
    ungroup() %>%
    na.omit()}


data_q2_second <- function(selected_countries, selected_gender){survey %>%
    filter(Subregion %in% selected_countries) %>%
    filter(Gender %in% selected_gender) %>%
    select(sog_w2_wrrd_food_yes,sog_w2_wrrd_food_no,Subregion) %>%
    rename('yes' = sog_w2_wrrd_food_yes,
           'no' = sog_w2_wrrd_food_no) %>%
    melt(id.vars = "Subregion") %>%
    na.omit() %>%
    distinct() %>%
    group_by(Subregion, variable) %>%
    summarise(value = ifelse(length(selected_gender) == 1, (sum(as.numeric(value)) * 100 / 200), 
                             (sum(as.numeric(value)) * 100 / 400)), .groups = 'drop') %>%
    na.omit()}


data_q3_first <- function(country, selected_gender) {survey %>%
    filter(Subregion == country) %>%
    filter(Gender %in% selected_gender) %>%
    select(sog_w2_access_hh_mny_full,sog_w2_access_hh_mny_limited,Subregion) %>%
    rename('full' = sog_w2_access_hh_mny_full,
           'limited' = sog_w2_access_hh_mny_limited) %>%
    melt(id.vars = "Subregion") %>%
    na.omit() %>%
    group_by(variable) %>%
    mutate(value = ifelse(length(selected_gender) == 1, (sum(as.numeric(value)) * 100 / 200), (sum(as.numeric(value)) * 100 / 400))) %>%
    distinct() %>%
    ungroup() %>%
    na.omit()}


data_q3_second <- function(selected_countries, selected_gender){survey %>%
    filter(Subregion %in% selected_countries) %>%
    filter(Gender %in% selected_gender) %>%
    select(sog_w2_access_hh_mny_full,sog_w2_access_hh_mny_limited,Subregion) %>%
    rename('full' = sog_w2_access_hh_mny_full,
           'limited' = sog_w2_access_hh_mny_limited) %>%
    melt(id.vars = "Subregion") %>%
    na.omit() %>%
    distinct() %>%
    group_by(Subregion, variable) %>%
    summarise(value = ifelse(length(selected_gender) == 1, (sum(as.numeric(value)) * 100 / 200), 
                             (sum(as.numeric(value)) * 100 / 400)), .groups = 'drop') %>%
    na.omit()}



data_q4_first <- function(country, selected_gender) {survey %>%
    filter(Subregion == country) %>%
    filter(Gender %in% selected_gender) %>%
    select(sog_w2_own_comp, sog_w2_own_place, sog_w2_own_land,
           sog_w2_own_none, sog_w2_own_phone, sog_w2_own_vehi, Subregion) %>%
    rename('comp' = sog_w2_own_comp, 'place' = sog_w2_own_place, 
           'land' = sog_w2_own_land, 'none' = sog_w2_own_none, 
           'phone' = sog_w2_own_phone, 'vehicle' = sog_w2_own_vehi) %>%
    melt(id.vars = "Subregion") %>%
    na.omit() %>%
    group_by(variable) %>%
    mutate(value = ifelse(length(selected_gender) == 1, (sum(as.numeric(value)) * 100 / 200), (sum(as.numeric(value)) * 100 / 400))) %>%
    distinct() %>%
    ungroup()}


data_q4_second <- function(selected_countries, selected_gender){survey %>%
    filter(Subregion %in% selected_countries) %>%
    filter(Gender %in% selected_gender) %>%
    select(sog_w2_own_comp, sog_w2_own_place, sog_w2_own_land,
           sog_w2_own_none, sog_w2_own_phone, sog_w2_own_vehi, Subregion) %>%
    rename('comp' = sog_w2_own_comp, 'place' = sog_w2_own_place, 
           'land' = sog_w2_own_land, 'none' = sog_w2_own_none, 
           'phone' = sog_w2_own_phone, 'vehicle' = sog_w2_own_vehi) %>%
    melt(id.vars = "Subregion") %>%
    na.omit() %>%
    distinct() %>%
    group_by(Subregion, variable) %>%
    summarise(value = ifelse(length(selected_gender) == 1, (sum(as.numeric(value)) * 100 / 200), 
                             (sum(as.numeric(value)) * 100 / 400)), .groups = 'drop')}




data_q5_first <- function(country, selected_gender) {survey %>%
    filter(Subregion == country) %>%
    filter(Gender %in% selected_gender) %>%
    select(a1_agree, a1_neutral,
           a1_disagree, Subregion) %>%
    rename('agree' = a1_agree, 'neutral' = a1_neutral,
           'disagree' = a1_disagree) %>%
    melt(id.vars = "Subregion") %>%
    na.omit() %>%
    group_by(variable) %>%
    mutate(value = ifelse(length(selected_gender) == 1, (sum(as.numeric(value)) * 100 / 200), (sum(as.numeric(value)) * 100 / 400))) %>%
    distinct() %>%
    ungroup()}


data_q5_second <- function(selected_countries, selected_gender){survey %>%
    filter(Subregion %in% selected_countries) %>%
    filter(Gender %in% selected_gender) %>%
    select(a1_agree, a1_neutral,
           a1_disagree, Subregion) %>%
    rename('agree' = a1_agree, 'neutral' = a1_neutral,
           'disagree' = a1_disagree) %>%
    melt(id.vars = "Subregion") %>%
    na.omit() %>%
    distinct() %>%
    group_by(Subregion, variable) %>%
    summarise(value = ifelse(length(selected_gender) == 1, (sum(as.numeric(value)) * 100 / 200), 
                             (sum(as.numeric(value)) * 100 / 400)), .groups = 'drop')}



data_q6_first <- function(country, selected_gender) {survey %>%
    filter(Subregion == country) %>%
    filter(Gender %in% selected_gender) %>%
    select(b3_dependent, b3_fullyindependent, Subregion) %>%
    rename('dependent' = b3_dependent, 'independent' = b3_fullyindependent) %>%
    melt(id.vars = "Subregion") %>%
    na.omit() %>%
    group_by(variable) %>%
    mutate(value = ifelse(length(selected_gender) == 1, (sum(as.numeric(value)) * 100 / 200), (sum(as.numeric(value)) * 100 / 400))) %>%
    distinct() %>%
    ungroup() %>%
    na.omit()}


data_q6_second <- function(selected_countries, selected_gender){survey %>%
    filter(Subregion %in% selected_countries) %>%
    filter(Gender %in% selected_gender) %>%
    select(b3_dependent, b3_fullyindependent, Subregion) %>%
    rename('dependent' = b3_dependent, 'independent' = b3_fullyindependent) %>%
    melt(id.vars = "Subregion") %>%
    na.omit() %>%
    distinct() %>%
    group_by(Subregion, variable) %>%
    summarise(value = ifelse(length(selected_gender) == 1, (sum(as.numeric(value)) * 100 / 200), 
                         (sum(as.numeric(value)) * 100 / 400)), .groups = 'drop') %>%
    na.omit()}




data_q7_first <- function(country, selected_gender) {survey %>%
    filter(Subregion == country) %>%
    filter(Gender %in% selected_gender) %>%
    select(b6_wage, b6_non_wage, Subregion) %>%
    rename('wage' = b6_wage, 'non-wage' = b6_non_wage) %>%
    melt(id.vars = "Subregion") %>%
    na.omit() %>%
    group_by(variable) %>%
    mutate(value = ifelse(length(selected_gender) == 1, (sum(as.numeric(value)) * 100 / 200), (sum(as.numeric(value)) * 100 / 400))) %>%
    distinct() %>%
    ungroup()}


data_q7_second <- function(selected_countries, selected_gender){survey %>%
    filter(Subregion %in% selected_countries) %>%
    filter(Gender %in% selected_gender) %>%
    select(b6_wage, b6_non_wage, Subregion) %>%
    rename('wage' = b6_wage, 'non-wage' = b6_non_wage) %>%
    melt(id.vars = "Subregion") %>%
    na.omit() %>%
    distinct() %>%
    group_by(Subregion, variable) %>%
    summarise(value = ifelse(length(selected_gender) == 1, (sum(as.numeric(value)) * 100 / 200), 
                             (sum(as.numeric(value)) * 100 / 400)), .groups = 'drop')}


data_q8_first <- function(country, selected_gender) {survey %>%
    filter(Subregion == country) %>%
    filter(Gender %in% selected_gender) %>%
    select(c1a_all, c1a_occasionally, Subregion) %>%
    rename('always' = c1a_all, 'occasionally' = c1a_occasionally) %>%
    melt(id.vars = "Subregion") %>%
    na.omit() %>%
    group_by(variable) %>%
    mutate(value = ifelse(length(selected_gender) == 1, (sum(as.numeric(value)) * 100 / 200), (sum(as.numeric(value)) * 100 / 400))) %>%
    distinct() %>%
    ungroup()}


data_q8_second <- function(selected_countries, selected_gender){survey %>%
    filter(Subregion %in% selected_countries) %>%
    filter(Gender %in% selected_gender) %>%
    select(c1a_all, c1a_occasionally, Subregion) %>%
    rename('always' = c1a_all, 'occasionally' = c1a_occasionally) %>%
    melt(id.vars = "Subregion") %>%
    na.omit() %>%
    distinct() %>%
    group_by(Subregion, variable) %>%
    summarise(value = ifelse(length(selected_gender) == 1, (sum(as.numeric(value)) * 100 / 200), 
                             (sum(as.numeric(value)) * 100 / 400)), .groups = 'drop')}


data_q9_first <- function(country, selected_gender) {survey %>%
    filter(Subregion == country) %>%
    filter(Gender %in% selected_gender) %>%
    select(c1b_spouse, c1b_nonspouse, Subregion) %>%
    rename('spouse' = c1b_spouse, 'nonspouse' = c1b_nonspouse) %>%
    melt(id.vars = "Subregion") %>%
    na.omit() %>%
    group_by(variable) %>%
    mutate(value = ifelse(length(selected_gender) == 1, (sum(as.numeric(value)) * 100 / 200), (sum(as.numeric(value)) * 100 / 400))) %>%
    distinct() %>%
    ungroup()}


data_q9_second <- function(selected_countries, selected_gender){survey %>%
    filter(Subregion %in% selected_countries) %>%
    filter(Gender %in% selected_gender) %>%
    select(c1b_spouse, c1b_nonspouse, Subregion) %>%
    rename('spouse' = c1b_spouse, 'nonspouse' = c1b_nonspouse) %>%
    melt(id.vars = "Subregion") %>%
    na.omit() %>%
    distinct() %>%
    group_by(Subregion, variable) %>%
    summarise(value = ifelse(length(selected_gender) == 1, (sum(as.numeric(value)) * 100 / 200), 
                             (sum(as.numeric(value)) * 100 / 400)), .groups = 'drop')}




data_q10_first <- function(country, selected_gender) {survey %>%
    filter(Subregion == country) %>%
    filter(Gender %in% selected_gender) %>%
    select(c1d_increase, c1d_same, c1d_decrease, Subregion) %>%
    rename('increase' = c1d_increase, 'same' = c1d_same, 'decrease' = c1d_decrease) %>%
    melt(id.vars = "Subregion") %>%
    na.omit() %>%
    group_by(variable) %>%
    mutate(value = ifelse(length(selected_gender) == 1, (sum(as.numeric(value)) * 100 / 200), (sum(as.numeric(value)) * 100 / 400))) %>%
    distinct() %>%
    ungroup()}


data_q10_second <- function(selected_countries, selected_gender){survey %>%
    filter(Subregion %in% selected_countries) %>%
    filter(Gender %in% selected_gender) %>%
    select(c1d_increase, c1d_same, c1d_decrease, Subregion) %>%
    rename('increase' = c1d_increase, 'same' = c1d_same, 'decrease' = c1d_decrease) %>%
    melt(id.vars = "Subregion") %>%
    na.omit() %>%
    distinct() %>%
    group_by(Subregion, variable) %>%
    summarise(value = ifelse(length(selected_gender) == 1, (sum(as.numeric(value)) * 100 / 200), 
                             (sum(as.numeric(value)) * 100 / 400)), .groups = 'drop')}










ui <- navbarPage(
  theme = shinytheme("slate"),
  "INTERACTIVE DASHBOARD",
      tabPanel("About",
                 fluidPage(
                   useShinyjs(),
                   tags$style(
                     HTML("
        .about-section {
          height: 600px; /* Adjust the height as needed */
          overflow-y: scroll;
        }
        .about-subsection {
          margin-bottom: 50px; /* Adjust the spacing between subsections */
        }
        ")
                   ),
        div(
          class = "about-section",
          id = "about_section",
          div(
            class = "about-subsection text-center",
            h1("Welcome to Our Dashboard!"),
            img(src = "GEN.png", class = "custom-image"),
            p(), p(),
            p("Explore our interactive dashboard designed to empower and inform various stakeholders, including government officials, policymakers, law enforcement agencies, NGOs, schools, and other educational institutions about gender equality all over the world.", style = "font-size: 16.5px;"),
            p("This platform provides a comprehensive overview of gender equality based on aggregated weighted statistics at the regional level by gender. It presents data from the 2020 Survey on Gender Equality At Home and includes insights at the country and regional levels for the 2021 wave. For more information about data and the mentioned survey, please visit", style = "font-size: 16.5px;",
            HTML("<a href='https://data.humdata.org/dataset/survey-on-gender-equality-at-home#' target='_blank' style='color: #87cefa; font-size: 16.5px;'>https://data.humdata.org/dataset/survey-on-gender-equality-at-home#.</a>")),
          ),
          tags$style(
            HTML(".custom-image { width: 550px; height: 550px; }")
          ),
          
          
          div(
            class = "about-subsection text-center",
            h1("Who Can Use This Dashboard?"),
            img(src = "ppl.png", class = "custom-image1"),
            p(), p(),
            p("Our dashboard is tailored for the following audiences:", style = "font-size: 16.5px;"),
            HTML("<ul style='font-size: 16.5px; list-style-type: none; padding: 0; margin: 0;''>
                  <li>Government Officials</li>
                  <li>Policymakers</li>
                  <li>Law Enforcement Agencies</li>
                  <li>Non-Governmental Organizations (NGOs)</li>
                  <li>Schools and Other Educational Institutions</li>
                </ul>"
            ),
            tags$style(
              HTML(".custom-image1 { width: 720px; height: 450px; }")
            ),
          ),
          
          
          
          div(
            class = "about-subsection text-center",
            h1("Key Functionalities"),
            img(src = "functionality.png", class = "custom-image3"),
            div( style = "text-align: center;",
            p("Our interactive dashboard offers the following functionalities:", style = "font-size: 16.5px;"),
            HTML("<ul style='font-size: 16.5px; list-style-type: none; padding: 0; margin: 0;''>
                  <li>Dynamic Selection: Choose specific countries, questions, and gender categories to get the insights.</li>
                  <li>Visualization Types: Explore data through various visualization types, including Bar Charts, Line Charts, Heatmaps, Scatterplots, Pie Charts, and Error Bars.</li>
                  <li>Data Exploration: Dive deep into gender equality metrics, resource access for both genders and attitudes about equality.</li>
                  <li>User-Friendly Interface: Navigate seamlessly through the dashboard for a user-friendly experience.</li>
                </ul>"
            )),
            tags$style(
              HTML(".custom-image3 { width: 600px; height: 600px; }")
            ),
          ),
          
          
          
          
          div(
            class = "about-subsection",
            h2("About Us"),
            p("The dashboard was created by a student of American University of Armenia. For inquiries, please contact us at:", style = "font-size: 16.5px;"),
            p("nane_mambreyan@edu.aua.am", style = "font-size: 16.5px;"),
            p("Also, connect with AUA community on social media:", style = "font-size: 16.5px;"),
            HTML("<a href='https://www.instagram.com/aua_insta/?hl=en' target='_blank' style='color: #87cefa; font-size: 16.5px;'>AUA Instagram page</a>"),
            br(),
            HTML("<a href='https://www.facebook.com/AUArmenia/' target='_blank' style='color: #87cefa; font-size: 16.5px;'>AUA Facebook page</a>")
          
            )
        )
                 )
        ),
  tabPanel("Gender Equality",
           sidebarLayout(
             sidebarPanel(
               selectizeInput("country", "Select Country:",
                              choices = country_options,
                              selected = "Armenia", 
                              multiple = TRUE, options = list(maxItems = 6)),
               selectizeInput("question", "Select question:",
                              choices = question_choices,
                              selected = question_choices[1], 
                              multiple = FALSE),
               selectizeInput("gender", "Select gender:",
                              choices = c('Female', 'Male'),
                              selected = 'Female', 
                              multiple = TRUE),
               selectInput("visualization_type", "Select Visualization Type:",
                           choices = c("Bar Chart", "Line Chart", "Heatmap", 'Scatterplot', 
                                       'Pie Chart', 'Error Bar'),
                           selected = "Bar Chart"),
             ),
             mainPanel(
               plotlyOutput("myPlot", height = '640px')
             )
           )
  )
)




server <- function(input, output, session) {
  
  
  observe({
    if (input$visualization_type == "Pie Chart" && length(input$country) > 4) {
      showModal(
        modalDialog(
          title = "Warning",
          paste0(paste("For this type of visualization, the maximum number of countries is 4. Some countries will be removed. 
                You will now see information for", paste(input$country[1:4], collapse = ",\n"), '.')),
          footer = tagList(
            actionButton("okButton", "OK", class = "btn-success")
          )
        )
      )
      
      updateSelectizeInput(session, "country", selected = input$country[1:4])
    }
  })
  
  observeEvent(input$okButton, {
    removeModal()
  })
  

  
  output$myPlot <- renderPlotly({
    selected_countries <- input$country
    selected_q <- input$question
    selected_viz <- input$visualization_type
    selected_gender <- input$gender
    
    if (length(selected_countries) == 0) {
      return(
        plot_ly(
          type = "scatter",
          mode = "text",
          x = 0.5,
          y = 0.5,
          text = "No country has been selected.",
          showlegend = FALSE
        ) %>%
          layout(
            font = list(size = 20),
            xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
            yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE)
          )
      )
    }
    
    if (length(selected_gender) == 0) {
      return(
        plot_ly(
          type = "scatter",
          mode = "text",
          x = 0.5,
          y = 0.5,
          text = "No gender has been selected.",
          showlegend = FALSE
        ) %>%
          layout(
            xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
            yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE)
          )
      )
    }
    
#draft
    if (selected_viz == 'Pie Chart') {
      
      
      fig <- plot_ly()
      
      for (country in selected_countries) {
        
        
        if (selected_q == question_choices[1]) {data <- data_q1_first(country, selected_gender)}
        if (selected_q == question_choices[2]) {data <- data_q2_first(country, selected_gender)}
        if (selected_q == question_choices[3]) {data <- data_q3_first(country, selected_gender)}
        if (selected_q == question_choices[4]) {data <- data_q4_first(country, selected_gender)}
        if (selected_q == question_choices[5]) {data <- data_q5_first(country, selected_gender)}
        if (selected_q == question_choices[6]) {data <- data_q6_first(country, selected_gender)}
        if (selected_q == question_choices[7]) {data <- data_q7_first(country, selected_gender)}
        if (selected_q == question_choices[8]) {data <- data_q8_first(country, selected_gender)}
        if (selected_q == question_choices[9]) {data <- data_q9_first(country, selected_gender)}
        if (selected_q == question_choices[10]) {data <- data_q10_first(country, selected_gender)}
        
        
        hover_text <- paste("Country: ", data$Subregion, 
                            "<br>Option: ", data$variable, 
                            "<br>Answer: ", data$value, "%")
        
        if (country == selected_countries[length(selected_countries)]) {
          fig <- fig %>% add_trace(data,
                                   r = sqrt(data$value),
                                   theta = data$variable,
                                   type = 'barpolar',
                                   text = hover_text,
                                   hoverinfo = 'text',
                                   marker = list(color = data$value, colorscale = 'YlGn', colorbar = list(title = 'Answer(%)')),
                                   subplot = paste0('polar', which(selected_countries == country)),
                                   legendgroup = 'group',
                                   showlegend = F 
          ) }
        else {
          fig <- fig %>% add_trace(data,
                                   r = sqrt(data$value),
                                   theta = data$variable,
                                   type = 'barpolar',
                                   text = hover_text,
                                   hoverinfo = 'text',
                                   marker = list(color = data$value, colorscale = 'YlGn'),
                                   subplot = paste0('polar', which(selected_countries == country)),
                                   legendgroup = 'group',
                                   showlegend = F )
          
        }
        
      }
      
      if (length(selected_countries) == 4) {
        fig <- fig %>%
          layout(
            polar = list(
              radialaxis = list(showgrid = F, showticklabels = F, showline = F, tickvals = list()),
              angularaxis = list(showgrid = F),
              domain = list(x = c(0, 0.46), y = c(0.56, 1))),
            polar2 = list(
              radialaxis = list(showgrid = F, showticklabels = F, showline = F, tickvals = list()),
              angularaxis = list(showgrid = F),
              domain = list(x = c(0.54, 1), y = c(0.56, 1))),
            polar3 = list(
              radialaxis = list(showgrid = F, showticklabels = F, showline = F, tickvals = list()),
              angularaxis = list(showgrid = F),
              domain = list(x = c(0, 0.46), y = c(0, 0.44))),
            polar4 = list(
              radialaxis = list(showgrid = F, showticklabels = F, showline = F, tickvals = list()),
              angularaxis = list(showgrid = F),
              domain = list(x = c(0.54, 1), y = c(0, 0.44)))
          )
      } else if (length(selected_countries) == 3) {
        fig <- fig %>%
          layout(
            polar = list(
              radialaxis = list(showgrid = F, showticklabels = F, showline = F, tickvals = list()),
              angularaxis = list(showgrid = F),
              domain = list(x = c(0, 0.46), y = c(0.56, 1))),
            polar2 = list(
              radialaxis = list(showgrid = F, showticklabels = F, showline = F, tickvals = list()),
              angularaxis = list(showgrid = F),
              domain = list(x = c(0.54, 1), y = c(0.56, 1))),
            polar3 = list(
              radialaxis = list(showgrid = F, showticklabels = F, showline = F, tickvals = list()),
              angularaxis = list(showgrid = F),
              domain = list(x = c(0.25, 0.75), y = c(0, 0.44)))
          )
      } else if (length(selected_countries) == 2) {
        fig <- fig %>%
          layout(
            polar = list(
              radialaxis = list(showgrid = F, showticklabels = F, showline = F, tickvals = list()),
              angularaxis = list(showgrid = F),
              domain = list(x = c(0, 0.5), y = c(0.5, 1))),
            polar2 = list(
              radialaxis = list(showgrid = F, showticklabels = F, showline = F, tickvals = list()),
              angularaxis = list(showgrid = F),
              domain = list(x = c(0.5, 1), y = c(0, 0.5)))
          )
      } else if (length(selected_countries) == 1) {
        fig <- fig %>%
          layout(
            polar = list(
              radialaxis = list(showgrid = F, showticklabels = F, showline = F, tickvals = list()),
              angularaxis = list(showgrid = F),
              domain = list(x = c(0, 1), y = c(0, 1)))
          )
      }
      
      return(fig)
    }

    
    if (!(selected_viz %in% c('Heatmap', 'Scatterplot', 'Error Bar', 'Pie Chart'))) {
      plots <- lapply(selected_countries[1:min(6, length(selected_countries))], function(country) {
        data <- NULL 
        
        if (selected_q == question_choices[1]) {data <- data_q1_first(country, selected_gender)}
        if (selected_q == question_choices[2]) {data <- data_q2_first(country, selected_gender)}
        if (selected_q == question_choices[3]) {data <- data_q3_first(country, selected_gender)}
        if (selected_q == question_choices[4]) {data <- data_q4_first(country, selected_gender)}
        if (selected_q == question_choices[5]) {data <- data_q5_first(country, selected_gender)}
        if (selected_q == question_choices[6]) {data <- data_q6_first(country, selected_gender)}
        if (selected_q == question_choices[7]) {data <- data_q7_first(country, selected_gender)}
        if (selected_q == question_choices[8]) {data <- data_q8_first(country, selected_gender)}
        if (selected_q == question_choices[9]) {data <- data_q9_first(country, selected_gender)}
        if (selected_q == question_choices[10]) {data <- data_q10_first(country, selected_gender)}
        
        if (selected_viz == "Bar Chart") {
          plot_ly(data, x = ~variable, y = ~value, type = 'bar', name = country) %>%
            layout(
              xaxis = list(title = 'Options', ticklen = 2.5, tickcolor = 'rgba(0, 0, 0, 0)'),
              yaxis = list(title = 'Answer(%)')
            )
        } else   {
          plot_ly(data, x = ~variable, y = ~value, type = 'scatter', mode = 'lines+markers', name = country) %>%
            layout(
              xaxis = list(title = 'Options'),
              yaxis = list(title = 'Answer(%)'))
        } 
      })
      
      subplot(do.call(list, plots), nrows = ceiling(length(plots) / 2), shareX = TRUE, shareY = TRUE) %>%
        layout(legend = list(orientation = "h", x = 0.1, y = -0.2, traceorder = "normal"))
      
    } else {
      data <- NULL  
      
      if (selected_q == question_choices[1]) {data <- data_q1_second(selected_countries, selected_gender)}
      if (selected_q == question_choices[2]) {data <- data_q2_second(selected_countries, selected_gender)}
      if (selected_q == question_choices[3]) {data <- data_q3_second(selected_countries, selected_gender)}
      if (selected_q == question_choices[4]) {data <- data_q4_second(selected_countries, selected_gender)}
      if (selected_q == question_choices[5]) {data <- data_q5_second(selected_countries, selected_gender)}
      if (selected_q == question_choices[6]) {data <- data_q6_second(selected_countries, selected_gender)}
      if (selected_q == question_choices[7]) {data <- data_q7_second(selected_countries, selected_gender)}
      if (selected_q == question_choices[8]) {data <- data_q8_second(selected_countries, selected_gender)}
      if (selected_q == question_choices[9]) {data <- data_q9_second(selected_countries, selected_gender)}
      if (selected_q == question_choices[10]) {data <- data_q10_second(selected_countries, selected_gender)}
      
      
      
      if (selected_viz == 'Heatmap') {
        hover_text <- paste("Country: ", data$Subregion, 
                            "<br>Option: ", data$variable, 
                            "<br>Answer: ", data$value, "%")
        
        plot_ly(data, x = ~variable, y = ~Subregion, z = ~value, showlegend = F,
                type = 'heatmap', colorbar = list(title = "Answer(%)"), 
                text = hover_text, 
                hoverinfo = 'text') %>%
          layout(
            xaxis = list(title = 'Option'),
            yaxis = list(title = list(text = 'Country',  standoff = 13))  # Use 'hoverinfo' instead of 'hover_info'
          )
        
        
        
      } else if (selected_viz == 'Scatterplot') {
        plot_ly(data, x = ~variable, y = ~value, type = 'scatter', mode = 'markers', color = ~Subregion, size = 4) %>%
          layout(legend = list(orientation = "h", x = 0.1, y = -0.2),
                 xaxis = list(title = 'Options'),
                 yaxis = list(title = 'Answer(%)'))
        
      } else if (selected_viz == 'Error Bar') {
        # p <- ggplot(data, aes(x = variable, y = value)) +
        #   stat_summary(fun.data = mean_sdl, geom = "errorbar",
        #                fun.args = list(mult = 2)) +
        #   labs(x = 'options', y = 'Answer(%)') +
        #   stat_summary(fun = mean, geom = 'point', color = 'red', size = 4, 
        #                ) +
        #   theme_minimal() +
        #   theme(axis.line = element_line(color = "black", size = 1))
        # 
        p <- ggplot(data, aes(x = variable, y = value)) +
          stat_summary(aes(group = 1), fun.data = function(x) {
            ymin <- mean(x) - (2 * sd(x))
            ymax <- mean(x) + (2 * sd(x))
            data.frame(ymin = ymin, ymax = ymax, y = mean(x))
          }, geom = "errorbar") +
          labs(x = 'options', y = 'Answer(%)') +
          stat_summary(fun = mean, geom = 'point', color = 'red', size = 4) +
          theme_minimal() +
          theme(axis.line = element_line(color = "black", linewidth = 1))
        
        p_plotly <- ggplotly(p)
        
        p_plotly <- p_plotly %>%
          style(text = paste(glue("Mean for {data$variable}: "), round(data$value, 2)))
        return(p_plotly)
      }
    }
  })
 
}

shinyApp(ui, server)


